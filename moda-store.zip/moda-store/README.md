# 🛍️ MODA Store — متجر الملابس الرجالي

## 📁 هيكل المشروع
```
moda-store/
├── app.py              ← Flask Backend + API
├── requirements.txt    ← المكتبات المطلوبة
├── moda.db             ← قاعدة البيانات (بتتعمل أوتوماتيك)
└── static/
    └── index.html      ← الفرونت اند
```

## 🚀 خطوات التشغيل

### 1. تثبيت Python (لو مش موجود)
- حمّل من: https://www.python.org/downloads/

### 2. تثبيت المكتبات
```bash
pip install -r requirements.txt
```

### 3. تشغيل السيرفر
```bash
python app.py
```

### 4. افتح المتصفح
```
http://localhost:5000
```

---

## 🔑 بيانات الدخول الافتراضية

| الدور  | الإيميل           | الباسورد  |
|--------|-------------------|-----------|
| أدمن   | admin@moda.com    | admin123  |

---

## 🌐 API Endpoints

| Method | Endpoint                    | الوصف                     |
|--------|-----------------------------|---------------------------|
| GET    | /api/products               | جلب كل المنتجات           |
| GET    | /api/products?category=رسمي | فلتر بالتصنيف             |
| GET    | /api/products?sale=1        | منتجات التخفيضات          |
| POST   | /api/products               | إضافة منتج جديد           |
| PUT    | /api/products/:id           | تعديل منتج                |
| DELETE | /api/products/:id           | حذف منتج                  |
| POST   | /api/login                  | تسجيل الدخول              |
| POST   | /api/register               | إنشاء حساب جديد           |
| GET    | /api/orders                 | جلب كل الطلبات            |
| POST   | /api/orders                 | إنشاء طلب جديد            |
| PUT    | /api/orders/:id/status      | تحديث حالة الطلب          |
| GET    | /api/stats                  | إحصائيات لوحة التحكم      |

---

## 🛠️ للرفع على سيرفر حقيقي (Production)
استخدم Gunicorn:
```bash
pip install gunicorn
gunicorn -w 4 app:app
```

أو ارفعه على: **Railway / Render / PythonAnywhere** مجاناً ✅
